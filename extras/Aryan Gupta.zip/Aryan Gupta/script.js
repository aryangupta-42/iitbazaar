$(document).ready(function(){
	$('.page').css('top',$(window).height());
	$('.mtit').css('margin-top',($(window).height()/2 - 140)+'px');
	$(document).scroll(function(){
		var st = $(document).scrollTop();
		if (st/100 <= 8) {
			$('.page1').css('-webkit-filter','blur('+ st/100 +'px)')
			$('.mtit,.fatline,.page1 .btn').css('opacity',1-st/600);
			$('.page1').css('transform','translateY(-'+ st/10 +'px)')
			//$('#can').css('-webkit-filter','blur('+ st/100 +'px)')
			$('#can').css('transform','translateY(-'+ st/30 +'px)')
			$('.header').css('background-color','rgba(255,255,255,1)')
		}else{
			$('.page1').css('-webkit-filter','blur('+ 0 +'px)');
			$('.mtit,.fatline,.page1 .btn').css('opacity','0');
			$('.page1').css('transform','translateY(-'+ 0 +'px)')
			$('#can').css('-webkit-filter','blur('+ 0 +'px)');
			$('#can').css('transform','translateY(-'+ 0 +'px)')
		}
		if (st >= $('.page2').offset().top) {
			$('.header').css('background-color','rgba(255,255,255,0.8)')
		}else{
			$('.header').css('background-color','rgba(255,255,255,0.99)')
		}
		if (st >= $('.page3').offset().top - 50 && st <= $('.page4').offset().top - 40) {
			$('.header').css({
				'background-color':'rgba(0,0,0,0.7)',
				'color':'white'
			})
		}else{
			$('.header').css({
				'color':'black'
			})
		}
		var pg4height = $('.page5').offset().top - $('.page4').offset().top 
		if (st>=$('.page4').offset().top - 50 && st <= ($('.page4').offset().top + pg4height/2)) {
			$('.leftcard').css({
				'transform':'translateY('+ (st - $('.page4').offset().top)/10+'px)'
			})
			$('.rightcard').css({
				'transform':'translateY(-'+ (st - $('.page4').offset().top)/10+'px)'
			})
		}
	})
	$('form').submit(function(e){
		e.preventDefault();
		if ($('#name').val()!=""&&$('#email').val()!=""&&$('textarea').val()!="") {
			$('.status').css({
				'opacity':'1',
				'background-color':'#2ecc91'
			})
			$('.status').html('Your response has been recorded.')
			$('#name').val("");
			$('#email').val("");
			$('textarea').val("");			
		}else{
			$('.status').css({
				'opacity':'1',
				'background-color':'#f75c3c'
			})
			$('.status').html('Whoops...Something went wrong.')			
		}
			setTimeout(function(){
				$('.status').css({
					'opacity':'0'
				})				
			},3000)
	})
	
//------------scrolling control-----------------

	$('.classybtn').click(function(){
		$('html,body').animate({
			scrollTop : $('.page1').offset().top
		},500,);
	})

	$('#h1').click(function(){
		$('html,body').animate({
			scrollTop : 0
		},500,);
	})
	$('#h2').click(function(){
		$('html,body').animate({
			scrollTop : $('.page2').offset().top
		},500,);
	})
	$('#h3').click(function(){
		$('html,body').animate({
			scrollTop : $('.page3').offset().top
		},500,);
	})
	$('#h4').click(function(){
		$('html,body').animate({
			scrollTop : $('.page4').offset().top
		},500,);
	})
	$('#h5').click(function(){
		$('html,body').animate({
			scrollTop : $('.page5').offset().top
		},500,);
	})



// -----------mobile optimization--------------------
	if ($('.skillcard .cardbodycont').height() >= 300) {
		$('.skillcard').css('height','500px');
		$('.skillcardcont2').css('top','500px');
		$('.cardcontent').css({
				'width':'90%'
			})
		$('.skillimg').css({
			'display':'block',
			'top':'30px',
			'left':'0px',
			'margin-left':'0px',
			'margin':'auto',
		})
		$('.page3').css('padding-bottom','200px')
	}
	$('.projcardtit').css('padding-left',$('.projectcard .thline').css('margin-left'));


// ----------------canvas-------------------------
	var can = $('#can')[0];
	can.width = $(window).width();
	can.height = $(window).height();

	var ctx = can.getContext("2d");
	// for (var i = 0; i < 50; i++) {
	// setTimeout(function(){
	// 	if (ctx.strokeStyle == #000){
	// 		ctx.strokeStyle = "#2ecc91";
	// 	}else if(ctx.strokeStyle == "#2ecc91"){
	// 		ctx.strokeStyle = "#000";
	// 	}
	// },200)
	function lineb(){
		var x = Math.floor(Math.random()*$(window).width());
		var y = Math.floor(Math.random()*$(window).height());
		// ctx.moveTo(x,y);
		// x = Math.floor(Math.random()*$(window).width());
		// y = Math.floor(Math.random()*$(window).height());
		ctx.globalalpha = 1;	
		ctx.lineTo(x,y);
		ctx.stroke();
		// ctx.fillRect(x,y,4,4);
		requestAnimationFrame(lineb);	
	}
	//lineb();


})