<div class="header">
  <div class="menuBtn">
    <img src="../images/homeico2.png" id="homeBtn">
  </div>
  <form class="" action="#" method="post">
    <button id="logout" name="logout">
      <img src="../images/power.png" id="logico">
    </button>
  </form>
  <div class="headerTitle">
    FacchakiT
  </div>
</div>
