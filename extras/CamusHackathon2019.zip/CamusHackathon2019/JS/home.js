$(document).ready(function(){
  $('#courses').click(function(){
    window.location.href = "../Courses/index.php"
  })
  $('#hostelrep').click(function(){
    window.location.href = "../HostelRep/index.php"
  })
  $('#mentor').click(function(){
    window.location.href = "../Mentor/index.php"
  })
  $('#search').click(function(){
    window.location.href = "../Search/index.php"
  })

})
