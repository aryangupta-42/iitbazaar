$(document).ready(function(){
  $('#timetable').click(function(){
    window.open('http://timetable.iitd.ac.in/schedule/1st%20yr_2nd_sem_2018_19.pdf ','_blank');
  })
  $('.menuBtn').click(function(){
    window.location.href = "../Home/index.php"
  })
})
