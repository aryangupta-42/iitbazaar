$(document).ready(function(){

  $('.menuBtn').click(function(){
    window.location.href = "../Home/index.php"
  })

})
